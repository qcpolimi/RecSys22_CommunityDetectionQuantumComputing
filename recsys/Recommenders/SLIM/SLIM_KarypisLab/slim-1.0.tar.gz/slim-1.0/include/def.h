/**************************************************************/
/*! \file 
    \brief This file contains all the defined macros
*/
/**************************************************************/


#ifndef __DEF_H__
#define __DEF_H__

/*! train file */
#define CMD_TRAIN_FILE        1
/*! test file */
#define CMD_TEST_FILE         2 
/*! model file */
#define CMD_MODEL_FILE        3
/*! debug level */
#define CMD_DBGLVL            4
/*! lambda */
#define CMD_LAMBDA            5
/*! beta */
#define CMD_BETA              6
/*! starti */
#define CMD_STARTI            7
/*! endi */
#define CMD_ENDI              8
/*! opttol */
#define CMD_OPTTOL            9
/*! max BCLS iterations */
#define CMD_MAX_BCLS_NITERS   10
/*! feature selection constrain file  */
#define CMD_FS_FILE           11
/*! feature selection */
#define CMD_FS                12
/*! number of features */
#define CMD_K                 13
/*! block size */
#define CMD_BSIZE             14
/*! help */
#define CMD_HELP              15
/*! nratings */
#define CMD_NRATINGS          16
/*! predition file */
#define CMD_PRED_FILE         17
/*! number of recommendations */
#define CMD_TOPN              18
/*! transpose matrix */
#define CMD_TRANSPOSE         19


/*! epsilon */
#define EPSILON               (1e-5)
/*! epsilon2 */
#define EPSILON2              (1e-10)

#endif

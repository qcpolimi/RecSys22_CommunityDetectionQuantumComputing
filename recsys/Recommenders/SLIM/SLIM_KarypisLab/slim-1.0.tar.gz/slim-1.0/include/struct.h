/**************************************************************/
/*! \file
  
    \brief This file contains all the necessary data structures
*/
/**************************************************************/


#ifndef __STRUCT_H__
#define __STRUCT_H__



/**************************************************************/
/*!   
    \brief A data structure for timer
 */
/**************************************************************/
typedef struct {

  /*! The start time */
  clock_t start; 
  /*! The end time */
  clock_t end;   

}ctimer_t; 



/**************************************************************/
/*!   
    \brief A data structure for ctrl parameters
 */
/**************************************************************/
typedef struct{

  /*! a file name that contains the training data in csr format */
  char * train_file; 
  /*! a file name that contains the testing data in csr format */
  char * test_file; 
  /*! a file name into which the model in csr format will be output */
  char * model_file;  
  /*! a file name into which the prediction will be output */
  char * pred_file; 

  /*! debug level, default 0 */
  int dbglvl; 

  /*! the regularization parameter for L-1 norm */
  double lambda; 
  /*! the regularization parameter for L-2 norm */
  double beta; 

  /*! the starting column index from which the coefficient matrix is calculated */
  int starti; 
  /*! the ending column index from which the coefficient matrix is calculated */
  int endi; 

  /*! optimality tolerance */
  double optTol; 
  /*! max number of iterations allowed in BCLS solver */
  int max_bcls_niters; 

  /*! lower bound for BCLS */
  double bl; 
  /*! upper bound for BCLS */
  double bu; 

  /*! if feature selection is applied */
  int fs; 
  /*! a file name which contains a constraint matrix in csr format for feature selection */
  char * fs_file; 

  /*! number of features to use if feature selection is applied*/
  int k;  

  /*! block size for data dump */
  int bsize; 

  /*! number of ratings */
  int nratings; 

  /*! the number of recommendations to be recommended */
  int topn; 

  /*! need to transpose the matrix */
  int transpose; 

}ctrl_t; 



/**************************************************************/
/*!
  \brief A matrix structure used for BCLS. This is adopted from 
         BCLS.
 */
/**************************************************************/
typedef struct cs_sparse{

  /*! maximum number of entries */
  int nzmax ;	    
  /*! number of rows */
  int m ;	    
  /*! number of columns */
  int n ;	    
  /*! column pointers (size n+1) or col indices (size nzmax) */
  int *p ;	    
  /*! row indices, size nzmax */
  int *i ;	    
  /*! numerical values, size nzmax */
  float *x ;	    
  /*! number of entries in triplet matrix, -1 for compressed-col */
  int nz ;	    

}cs;

/**************************************************************/
/*!
  \brief A workspace structure used for BCLS. This is adopated
         from BCLS.   
 */
/**************************************************************/
typedef struct {

  /*! a matrix*/
  cs *A;
  /*! max number of iterations allowed in BCLS solver */
  int max_bcls_niters; 
  /*! the active columns */
  int * acol; 

} worksp;



#endif

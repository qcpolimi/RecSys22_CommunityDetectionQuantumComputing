/**************************************************************/
/*! \file
  
    \brief This file contains all prototypes.
*/
/**************************************************************/


#ifndef __PROTO_H__
#define __PROTO_H__

/* cmd.c */
void parse_cmdline(ctrl_t *ctrl, int argc, char * argv[]); 

/* util.c */
ctrl_t * create_ctrl(); 
void free_ctrl(ctrl_t * ctrl); 
void start_timer(ctimer_t * ctimer); 
void end_timer(ctimer_t * ctimer); 
void display_timer(ctimer_t * ctimer, char * msg); 
int count_nnz(double * array, int narray); 
void find_topk(double * w, int n, int topk, double * map, int * topk2); 
void get_column(gk_csr_t * constraint, int i, double * w); 

/* io.c */
gk_csr_t * read_constraint(ctrl_t * ctrl, char * file); 
void csr_Write(gk_csr_t *mat, char *filename, char * mode, 
	       int format, int writevals, int numbering); 

/* check.c */
void check_train_test(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test); 

/* bcsol.c */
int call_back( BCLS *ls, void *UsrWrk ); 
int call_back_it( BCLS *ls, void *UsrWrk ); 
int pretty_printer( void *io_file, char *msg ); 
void *cs_free (void *p); 
void *cs_malloc (int n, size_t size); 
void *cs_calloc (int n, size_t size); 
cs *cs_spfree (cs *A); 
cs *cs_spalloc (int m, int n, int nzmax, int values, int triplet); 
void dload( const int n, const double alpha, double x[] ) ; 
int Aprod( int mode, int m, int n, int nix, int ix[],
	   double x[], double y[], void *UsrWrk ) ; 
void  bcsol(ctrl_t * ctrl, gk_csr_t * AA, double * bb, double * x, worksp * Wrk, 
	    double * bl, double * bu, 
	    double beta, double * c); 

/* slim_learn.c */
void slim_learn(ctrl_t * ctrl, gk_csr_t * train); 

/* slim_fs_learn.c */
void slim_fs_learn(ctrl_t * ctrl, gk_csr_t * A, double * b, double * w, float ** A_colval, 
		   worksp * Wrk, 
		   double * bl, double * bu, 
		   double beta, double * c); 

/* process.c */
void preprocess(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test); 

/* slim_test.c */
double * slim_test(ctrl_t * ctrl, gk_csr_t * model, 
		   gk_csr_t * train, gk_csr_t * test); 
int suggest_predict(ctrl_t * ctrl, gk_csr_t * model, int ** iidx, 
		    gk_csr_t * train, int u, gk_dkv_t ** rcmd); 
void slim_predict(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test, gk_csr_t * model); 

#endif

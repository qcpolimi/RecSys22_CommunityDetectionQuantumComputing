/**************************************************************/
/*! \file test_slim_learn.c
    \brief This is to test slim_learn

    \author    Xia Ning
    \version   1.0
    \date      2011-2012
    \copyright GNU Public License
*/
/**************************************************************/

#include<slim.h>

/**************************************************************/
/*! \brief The main entry for the learning
 */
/**************************************************************/
int main(int argc, char * argv[]){
  
  srand(0); 

  /* parse command line */
  ctrl_t * ctrl = create_ctrl(); 
  parse_cmdline(ctrl, argc, argv); 

  /* I/O */
  gk_csr_t * train = gk_csr_Read(ctrl->train_file, GK_CSR_FMT_CSR, 1, 1); 


  /* preprocess training data */
  preprocess(ctrl, train, NULL); 

  /* learning */
  slim_learn(ctrl, train); 


  /* clean up */
  free_ctrl(ctrl); 
  gk_csr_Free(&train); 


}

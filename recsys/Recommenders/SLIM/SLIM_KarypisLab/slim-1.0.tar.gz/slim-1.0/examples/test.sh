slim_learn -train_file=train.mat -test_file=test.mat  -model_file=ml100k_beta0.1_lambda5.mat -starti=0 -endi=1682 -lambda=5 -beta=0.1 -optTol=0.00001 -max_bcls_niters=10000


slim_predict -train_file=train.mat -test_file=test.mat -model_file=ml100k_beta0.1_lambda5.mat


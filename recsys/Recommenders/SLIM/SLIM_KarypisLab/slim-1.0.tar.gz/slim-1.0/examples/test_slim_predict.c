/**************************************************************/
/*! \file test_slim_predict.c
    \brief This is to test slim_predict

    \author    Xia Ning
    \version   1.0
    \date      2011-2012
    \copyright GNU Public License
*/
/**************************************************************/

#include<slim.h>

/**************************************************************/
/*! \brief The main entry for the testing
 */
/**************************************************************/
int main(int argc, char * argv[]){
  
  srand(0); 

  /* parse command line */
  ctrl_t * ctrl = create_ctrl(); 
  parse_cmdline(ctrl, argc, argv); 

  /* I/O */
  gk_csr_t * train = gk_csr_Read(ctrl->train_file, GK_CSR_FMT_CSR, 1, 1); 
  gk_csr_t * test  = gk_csr_Read(ctrl->test_file,  GK_CSR_FMT_CSR, 1, 1);
  gk_csr_t * model = gk_csr_Read(ctrl->model_file, GK_CSR_FMT_CSR, 1, 1); 

  /* preprocess training data */
  preprocess(ctrl, train, test); 
 

  /* learning */
  slim_predict(ctrl, train, test, model); 


  /* clean up */
  free_ctrl(ctrl); 
  gk_csr_Free(&train); 
  gk_csr_Free(&test); 
  gk_csr_Free(&model); 

}

/*!
\file gk_struct.h
\brief This file contains various datastructures used/provided by GKlib

\date   Started 3/27/2007
\author George
\version\verbatim $Id: gk_struct.h 7952 2010-02-10 21:20:11Z karypis $ \endverbatim
*/

#ifndef _GK_STRUCT_H_
#define _GK_STRUCT_H_


/********************************************************************/
/*! Generator for gk_??KeyVal_t data structure */
/********************************************************************/
#define GK_MKKEYVALUE_T(NAME, KEYTYPE, VALTYPE) \
typedef struct {\
  KEYTYPE key;\
  VALTYPE val;\
} NAME;\

/* The actual KeyVal data structures */
GK_MKKEYVALUE_T(gk_ckv_t,   char,     gk_idx_t)
GK_MKKEYVALUE_T(gk_ikv_t,   int,      gk_idx_t)
GK_MKKEYVALUE_T(gk_i32kv_t, int32_t,  gk_idx_t)
GK_MKKEYVALUE_T(gk_i64kv_t, int64_t,  gk_idx_t)
GK_MKKEYVALUE_T(gk_fkv_t,   float,    gk_idx_t)
GK_MKKEYVALUE_T(gk_dkv_t,   double,   gk_idx_t)
GK_MKKEYVALUE_T(gk_skv_t,   char *,   gk_idx_t)
GK_MKKEYVALUE_T(gk_idxkv_t, gk_idx_t, gk_idx_t)



/********************************************************************/
/*! Generator for gk_?pq_t data structure */
/********************************************************************/
#define GK_MKPQUEUE_T(NAME, KVTYPE)\
typedef struct {\
  gk_idx_t nnodes;\
  gk_idx_t maxnodes;\
\
  /* Heap version of the data structure */ \
  KVTYPE   *heap;\
  gk_idx_t *locator;\
} NAME;\

GK_MKPQUEUE_T(gk_ipq_t,    gk_ikv_t)
GK_MKPQUEUE_T(gk_i32pq_t,  gk_i32kv_t)
GK_MKPQUEUE_T(gk_i64pq_t,  gk_i64kv_t)
GK_MKPQUEUE_T(gk_fpq_t,    gk_fkv_t)
GK_MKPQUEUE_T(gk_dpq_t,    gk_dkv_t)
GK_MKPQUEUE_T(gk_idxpq_t,  gk_idxkv_t)



/*-------------------------------------------------------------
 * The following data structure stores a sparse CSR format
 *-------------------------------------------------------------*/
typedef struct {
  int nrows, ncols;
  int *rowptr, *colptr, *rowids;
  int *rowind, *colind, *colids;
  float *rowval, *colval;
  float *rnorms, *cnorms;
  float *rsums, *csums;
} gk_csr_t;


/*-------------------------------------------------------------
 * The following data structure stores stores a string as a 
 * pair of its allocated buffer and the buffer itself.
 *-------------------------------------------------------------*/
typedef struct {
  size_t len;
  char *buf;
} gk_str_t;




/*-------------------------------------------------------------
* The following data structure implements a string-2-int mapping
* table used for parsing command-line options
*-------------------------------------------------------------*/
typedef struct {
  char *name;
  int id;
} gk_StringMap_t;


/*------------------------------------------------------------
 * This structure implements a simple hash table
 *------------------------------------------------------------*/
typedef struct {
  int nelements;          /* The overall size of the hash-table */
  int htsize;             /* The current size of the hash-table */
  gk_ikv_t *harray;       /* The actual hash-table */
} gk_HTable_t;


/*------------------------------------------------------------
 * This structure implements a gk_Tokens_t list returned by the
 * string tokenizer
 *------------------------------------------------------------*/
typedef struct {
  int ntoks;        /* The number of tokens in the input string */
  char *strbuf;     /* The memory that stores all the entries */
  char **list;      /* Pointers to the strbuf for each element */
} gk_Tokens_t;

/*------------------------------------------------------------
 * This structure implements storage for an atom in a pdb file
 *------------------------------------------------------------*/
typedef struct {
	int       serial;
	char      *name;
	char			altLoc;
	char      *resname;
	char			chainid;	
	int       rserial;
	char			icode;
  char      element;
	double    x;
	double    y;
	double    z;
	double    opcy;
	double    tmpt;
} atom;


/*------------------------------------------------------------
 * This structure implements storage for a center of mass for
 * a single residue.
 *------------------------------------------------------------*/
typedef struct {
  char name;
  double x;
  double y;
  double z;
} center_of_mass;

/*------------------------------------------------------------
 * This structure implements storage for a pdb protein 
 *------------------------------------------------------------*/
typedef struct {
	int natoms;			/* Number of atoms */
	int nresidues;  /* Number of residues based on coordinates */
	int ncas;
	int nbbs;
	int corruption;
	char *resSeq;	      /* Residue sequence based on coordinates    */
  char **threeresSeq; /* three-letter residue sequence */
	atom *atoms;
	atom **bbs;
	atom **cas;
  center_of_mass *cm;
} pdbf;



/*************************************************************
 * Localization Structures for converting characters to integers
 *************************************************************/
typedef struct {
    int n;
    char *i2c;
    int *c2i;
} gk_i2cc2i_t;
 

/*******************************************************************
 *This structure implements storage of a protein sequence
 * *****************************************************************/
typedef struct {
    
    int len; /*Number of Residues */
    int *sequence; /* Stores the sequence*/
    
    
    int **pssm; /* Stores the pssm matrix */
    int **psfm; /* Stores the psfm matrix */
    char *name; /* Stores the name of the sequence */

    int nsymbols;

    
} gk_seq_t;

/*-------------------------------------------------------------*/
/*! Data structures for use within this module */
/*-------------------------------------------------------------*/
typedef struct {
  int minfreq;  /* the minimum frequency of a pattern */
  int maxfreq;  /* the maximum frequency of a pattern */
  int minlen;   /* the minimum length of the requested pattern */
  int maxlen;   /* the maximum length of the requested pattern */
  int tnitems;  /* the initial range of the item space */

  /* the call-back function */
  void (*callback)(void *stateptr, int nitems, int *itemids, int ntrans, int *transids); 
  void *stateptr;   /* the user-supplied pointer to pass to the callback */

  /* workspace variables */
  int *rmarker;
  gk_ikv_t *cand;
} isparams_t;



#endif

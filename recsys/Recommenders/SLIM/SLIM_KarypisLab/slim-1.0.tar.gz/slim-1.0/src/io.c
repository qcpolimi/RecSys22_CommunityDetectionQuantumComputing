/**************************************************************/
/*! \file
  
    \brief This file contains all the I/O routines 
*/
/**************************************************************/


#include<slim.h>



/**************************************************************/
/*! 
  \brief Read in a constraint matrix for feature selection
 */
/**************************************************************/
gk_csr_t * read_constraint(ctrl_t * ctrl, char * file){

  gk_csr_t * constraint = gk_csr_Read(file, GK_CSR_FMT_CSR, 1, 1); 

  if (ctrl->transpose){
    /* use the model from SLIM as constraint, which is transpose 
       of an item-item similarity matrix */
    constraint->colptr = constraint->rowptr;
    constraint->colind = constraint->rowind;
    constraint->colval = constraint->rowval;
    int tmp_ncols = constraint->ncols;
    constraint->ncols  = constraint->nrows;
    constraint->rowptr = NULL;
    constraint->rowind = NULL;
    constraint->rowval = NULL;
    constraint->nrows  = tmp_ncols;
    gk_csr_CreateIndex(constraint, GK_CSR_ROW);
  }else{
    /* use an item-item similarity matrix as constraint */
    gk_csr_CreateIndex(constraint, GK_CSR_COL); 
  }

  return constraint; 
}



/**************************************************************/
/*!  \brief Dump the csr into a file
 */
/**************************************************************/
void csr_Write(gk_csr_t *mat, char *filename, char * mode, 
	       int format, int writevals, int numbering) {

  int i, j;
  FILE *fpout;
  
  if (filename)
    fpout = gk_fopen(filename, mode, "gk_csr_Write: fpout");
  else
    fpout = stdout;

  if (format == GK_CSR_FMT_CLUTO) {
    fprintf(fpout, "%d %d %d\n", mat->nrows, mat->ncols, mat->rowptr[mat->nrows]);
    writevals = 1;
    numbering = 1;
  }
  
  for (i=0; i<mat->nrows; i++) {
    for (j=mat->rowptr[i]; j<mat->rowptr[i+1]; j++) {
      fprintf(fpout, " %d", mat->rowind[j]+(numbering ? 1 : 0));
      if (writevals)
	fprintf(fpout, " %.5f", mat->rowval[j]);
    }
    fprintf(fpout, "\n");
  }
  if (filename)
    gk_fclose(fpout); 

}

/**************************************************************/
/*! \file
  
    \brief This file contains all the routines for parameter
           setup from the user
*/
/**************************************************************/

#include<slim.h>

/**************************************************************/
/*!
  \brief A structure for command-line options
 */
/**************************************************************/
static struct gk_option slim_options[] = {
  {"train_file",               1,      0,       CMD_TRAIN_FILE}, 
  {"test_file",                1,      0,       CMD_TEST_FILE}, 
  {"model_file",               1,      0,       CMD_MODEL_FILE}, 
  {"pred_file",                1,      0,       CMD_PRED_FILE}, 
  {"dbglvl",                   1,      0,       CMD_DBGLVL}, 
  {"lambda",                   1,      0,       CMD_LAMBDA},
  {"beta",                     1,      0,       CMD_BETA}, 
  {"starti",                   1,      0,       CMD_STARTI}, 
  {"endi",                     1,      0,       CMD_ENDI}, 
  {"optTol",                   1,      0,       CMD_OPTTOL}, 
  {"max_bcls_niters",          1,      0,       CMD_MAX_BCLS_NITERS}, 
  {"fs_file",                  1,      0,       CMD_FS_FILE},
  {"fs",                       0,      0,       CMD_FS},
  {"k",                        1,      0,       CMD_K},
  {"bsize",                    1,      0,       CMD_BSIZE}, 
  {"nratings",                 1,      0,       CMD_NRATINGS}, 
  {"topn",                     1,      0,       CMD_TOPN}, 
  {"transpose",                1,      0,       CMD_TRANSPOSE}, 
  {"help",                     0,      0,       CMD_HELP}, 
  {0,                          0,      0,       0}
};



/**************************************************************/
/*! \brief Mini help
 */
/**************************************************************/
static char helpstr[][512] =  {
" ", 
" Usage",
" 	slim_learn [options]",
" ",
" 	 -train_file=string",
" 		Specifies the input file which contains the training data. This file should be",
" 		in .csr format. ",
" 		",
" 	 -test_file=string",
" 		Specifies the input file which contains the testing data. This file should be",
" 		in .csr format.",
" 	",
" 	 -model_file=string",
" 		Specifies the output file which will contains a model matrix. The output file will be in ",
" 		.csr format. ",
" ",
" 	 -fs_file=string",
" 		Specifies the input file which contains a matrix for feature selection purpose. This input ",
"               file should be in .csr format. This option takes effect only when -fs option is specified.",
" ", 
"        -pred_file=string", 
"               Specifies the output file which will contain the top-n prediction for each user.  The output", 
"               file wil be in .csr format. If this option is not specified, no prediction scores will be output.", 
" ", 
" 	 -lambda=float",
" 		Specifies the regularization parameter for the $\ell_1$ norm",
" 		",
" 	 -beta=flat",
" 		Specifies the regularizationi parameter for the $\ell_2$ norm",
" ",
" 	 -starti=int",
" 		Specifies the index of the first column (C-style indexing) from ",
" 		which the sparse coefficient matrix will be calculated. The default",
" 		value is 0.",
" ",
"  	 -endi=int",
" 		Specifies the index of the last column (exclusively) up to which",
" 		the sparse coefficient matrix will be calculated. The default value",
" 		is the number of total columns. ",
" ",
"        -transpose",
"               Specifies that the input feature selection matrix needs to be transposed.",  
" ",
" 	 -fs",
" 	 	Specifies that feature selection is required so as to accelerate the learning. ",
" ",
" 	 -k=int",
" 		Specifies the number of features if feature selection is applied. The default ",
" 		value is 50. ",
"          ", 
" 	 -dbglvl=int",
" 		Specifies the debug level. The default value is 0.",
" ",
" 	 -optTol=float",
" 		Specifies the threshold which control the optimization. Once the error",
" 		from two optimization iterations is smaller than this value, the optimization",
" 		process will be terminated. The default value is 1e-5.",
" ",
" 	 -max_bcls_niters=int",
" 		Specifies the maximum number of iterations that is allowed for optimization. ",
" 		Once the number of iterations reaches this value, the optimization process",
" 		will be terminated. The default value is 1e5.",
" ",
"        -bsize=int",
"               Specifies the block size for output. Once the calculation for these bsize ", 
"               blocks are done, they are dumped into the output file. The default value is 1000.",
" ", 
"        -nratings=int",
"               Specifies the number of unique rating values in the testing set. The rating values",  
"               should be integers starting from 1. The default value is 1.",
" ", 
"        -topn=int", 
"               Specifies the number of recommendations to be produced for each user. The default", 
"               value is 10.", 
" ",
"        -help",
"               Print this message.",  
" 			",
""
}; 

/**************************************************************/
/*! \brief A short help 
*/
/**************************************************************/
static char shorthelpstr[][100] = {
  " ",
  "   Usage: slim_learn [options] ",
  "          use 'slim_learn -help' for a summary of the options.",
""
};

/**************************************************************/
/*! \brief Entry point of the command-line argument parsing
  
    \param[out] ctrl  A ctrl structure to be filled out
    \param[in]  argc  Number of arguments
    \param[in]  argv  A list of arguments
*/
/**************************************************************/
void parse_cmdline(ctrl_t *ctrl, int argc, char * argv[]){

  int c = -1, option_index = -1;
  
  if (ctrl == NULL)
    ctrl = create_ctrl(); 

  while((c = gk_getopt_long_only(argc, argv, "", slim_options, &option_index)) != -1){
    switch(c){

      
    case CMD_TRAIN_FILE:
      ctrl->train_file = gk_strdup(gk_optarg); 
      break; 

    case CMD_TEST_FILE:
      ctrl->test_file = gk_strdup(gk_optarg); 
      break; 

    case CMD_MODEL_FILE:
      ctrl->model_file = gk_strdup(gk_optarg); 
      break; 

    case CMD_PRED_FILE:
      ctrl->pred_file = gk_strdup(gk_optarg); 
      break; 

    case CMD_DBGLVL:
      ctrl->dbglvl = atoi(gk_optarg); 
      break; 

    case CMD_LAMBDA:
      ctrl->lambda = atof(gk_optarg);
      break; 

    case CMD_BETA:
      ctrl->beta = atof(gk_optarg); 
      break; 

    case CMD_STARTI:
      ctrl->starti = atoi(gk_optarg); 
      break; 

    case CMD_ENDI:
      ctrl->endi = atoi(gk_optarg); 
      break; 

    case CMD_OPTTOL:
      ctrl->optTol = atof(gk_optarg); 
      break; 

    case CMD_MAX_BCLS_NITERS:
      ctrl->max_bcls_niters = atoi(gk_optarg); 
      break; 

    case CMD_FS:
      ctrl->fs = 1;
      break;

    case CMD_FS_FILE:
      ctrl->fs_file = gk_strdup(gk_optarg);
      break;

    case CMD_K:
      ctrl->k = atoi(gk_optarg);
      break;

    case CMD_BSIZE:
      ctrl->bsize = atoi(gk_optarg); 
      break; 

    case CMD_NRATINGS:
      ctrl->nratings = atoi(gk_optarg); 
      break; 

    case CMD_TOPN:
      ctrl->topn = atoi(gk_optarg); 
      break; 

    case CMD_TRANSPOSE:
      ctrl->transpose = 1; 
      break; 

    case CMD_HELP:
      for (int i=0; strlen(helpstr[i]) > 0; i++)
	printf("%s\n", helpstr[i]);
      exit(0);


    case '?':
    default:
      printf("Illegal command-line option(s) %s\n", gk_optarg);
      exit(0);

    }
  }


  if (argc-gk_optind != 0 || argc == 1) {
    for (int i=0; strlen(shorthelpstr[i]) > 0; i++)
      printf("%s\n", shorthelpstr[i]);
    exit(0);
  }


}

/**************************************************************/
/*! \file 
  
    \brief This file contains all the utility routines. 
*/
/**************************************************************/

#include<slim.h>




/**************************************************************/
/*! 
  \brief Create a ctrl structure wich contains all the default
         parameters for SLIM
 
  \return ctrl_t* A pointer to a created ctrl structure
*/
/**************************************************************/
ctrl_t * create_ctrl(){

  ctrl_t * ctrl = gk_malloc(sizeof(ctrl_t), "malloc ctrl"); 

  ctrl->train_file = NULL; 
  ctrl->test_file  = NULL; 
  ctrl->model_file = NULL; 
  ctrl->fs_file = NULL;
  ctrl->pred_file = NULL; 

  ctrl->dbglvl = 0; 

  ctrl->beta    = 1.0; 
  ctrl->lambda  = 1.0; 

  ctrl->starti = -1; 
  ctrl->endi = -1; 

  ctrl->optTol = 1e-5; 
  ctrl->max_bcls_niters = 100000; 

  ctrl->bl = 0;     
  ctrl->bu = 1e20;  

  ctrl->fs = 0;

  ctrl->k = 50;

  ctrl->bsize = 1000; 

  ctrl->nratings = 5; 

  ctrl->topn = 10; 

  ctrl->transpose = 0; 

  return ctrl; 

}

/**************************************************************/
/*! 
  \brief Free a ctrl structure
  
  \param[in] ctrl A pointer to a ctrl structure to be freed
*/
/**************************************************************/
void free_ctrl(ctrl_t * ctrl){

  gk_free((void **)&ctrl->model_file, LTERM); 
  gk_free((void **)&ctrl->train_file, LTERM); 
  gk_free((void **)&ctrl->test_file, LTERM); 
  gk_free((void **)&ctrl->pred_file, LTERM); 
  gk_free((void **)&ctrl->fs_file, LTERM); 

  gk_free((void **)&ctrl, LTERM); 

}


/**************************************************************/
/*! 
  \brief Start a timer to record current time
    
  \param[in] ctimer A timer to start
*/
/**************************************************************/
void start_timer(ctimer_t * ctimer){
  
  ctimer->start = clock(); 
  
}

/**************************************************************/
/*! 
  \brief End a timer to record a length of a duration
    
  \param[in] ctimer A timer to end
 */
/**************************************************************/
void end_timer(ctimer_t * ctimer){

  ctimer->end = clock(); 
  
}

/**************************************************************/
/*! 
  \brief Display a user-defined message and a duration length
         recorded by a timer
	   
  \param[in] ctimer A timer with a length of a duration recorded
  \param[in] msg    A user-defined message to display
*/
/**************************************************************/
void display_timer(ctimer_t * ctimer, char * msg){

  printf("----- elapsed CPU time for %s: %f s\n", msg, 
         (double)(ctimer->end - ctimer->start)/CLOCKS_PER_SEC);  
  fflush(stdout);

}

/**************************************************************/
/*! 
  \brief Count the number of non-zero values in an array
    
  \param[in]  array  An array whose non-zero values will be 
                       counted
  \param[in]  narray The length of the array
  \return     int    The number of non-zero values in the array
*/
/**************************************************************/
int count_nnz(double * array, int narray){

  int nnz = 0; 

  for (int i = 0; i < narray; i ++){
    if (array[i] > EPSILON2 || array[i] < -EPSILON2)
      nnz ++; 
  }

  return nnz; 

}

/**************************************************************/
/*! 
  \brief Find the top-k values from an array
  
  \param[in]  w     The array whose top-k values will be found
  \param[in]  n     The length of the array w
  \param[in]  topk  The number of top values to be found
  \param[out] map   The array of indices that correspond to the
                    top-k values in the input array
  \param[out] topk2 The actual number of top values that are found
 */
/**************************************************************/
void find_topk(double * w, int n, int topk, double * map, int * topk2){


  gk_dkv_t * wkv = gk_malloc(sizeof(gk_dkv_t)*n, "malloc wkv"); 
  int k2 = 0; 

  for (int i = 0; i < n; i ++){
    wkv[i].key = w[i]; 
    wkv[i].val = i; 
    if (w[i] > 1e-10) k2 ++; 
  }

  /* sort */
  gk_dkvsortd(n, wkv); 

  for (int i = 0; i < ((topk <= k2)? topk:k2); i ++){
    map[i] = wkv[i].val; 
  }
  
  *topk2 = ((topk <= k2)? topk:k2);
  gk_free((void **)&wkv, LTERM); 

}

/**************************************************************/
/*! 
  \brief Get a column from a csr matrix
  
  \param[in]  constraint A matrix from which one column is to 
                         be retrievd
  \param[in]  i          The index of the column to be retrieved
  \param[out] w          The output vector which saves the 
                         retrieved column
*/
/**************************************************************/
void get_column(gk_csr_t * constraint, int i, double * w){
 
  if (i > constraint->ncols){
    gk_dset(constraint->nrows, 0, w); 
  }
  else{
    int nnz = constraint->colptr[i+1] - constraint->colptr[i]; 
    for (int j = 0; j < nnz; j ++){
      int k = *(constraint->colptr[i] + j + constraint->colind); 
      w[k]  = *(constraint->colptr[i] + j + constraint->colval); 
    }
  }
}


/**************************************************************/
/*! \file
  
    \brief This file contains all the routines for SLIM learning
           with feature selection

*/
/**************************************************************/


#include<slim.h>


/**************************************************************/
/*! \brief SLIM learning with feature selction
    
    \param[in] ctrl A ctrl structure which contains all the 
                    parameters for SLIM Learning with feature 
		    selection
    \param[in]     A        The A matrix		    
    \param[in]     b        The RHS vector
    \param[in,out] w        The solution vector
    \param[in]     A_colval A temporary place for a column
    \param[in]     Wrk      A workspace for BCLS
    \param[in]     bl       The lower bound for BCLS
    \param[in]     bu       The upper bound for BCLS
    \param[in]     beta     The regularization parameter for L-2 norm
    \param[in]     c        The vector for L-1 norm
 */
/**************************************************************/
void slim_fs_learn(ctrl_t * ctrl, gk_csr_t * A, double * b, double * w, float ** A_colval, 
		   worksp * Wrk, 
		   double * bl, double * bu, 
		   double beta, double * c){

  int nnz = *(A->colptr + A->ncols); 
  int * acol = Wrk->acol; 

  /* count nnz */
  int kk = count_nnz(w, A->ncols); 
	
  /* find topk nnz */
  int topk = 0; 
  /* find the indices of topk entries, meanwhile w is over-written as the topk locations */
  find_topk(w, A->ncols, gk_min(ctrl->k, kk), w, &topk);  

  /* back up original values, this is done only once */
  if (*A_colval == NULL){
    *A_colval = gk_malloc(sizeof(float)*nnz, "malloc *A_colval"); 
    memcpy((void *)*A_colval, (void *)A->colval, sizeof(float)*nnz); 
  }

  /* remove all A nnz values, this will not affect the column under consideration */
  gk_fset(nnz, 0, A->colval); 
  /* set all columns as inactive */
  gk_iset(A->ncols, 0, acol);
  /* recover all topk columns in A */
  for (int i = 0; i < topk; i ++){
    int j = (int)w[i]; 
    /* activate this column */
    acol[j] = 1;  
    int nj = A->colptr[j+1] - A->colptr[j];
    for (int k = 0; k < nj; k ++){
      /* get the orignal values back */
      *(A->colptr[j] + k + A->colval) = *(A->colptr[j] + k + *A_colval); 
    }
  }

  /* BCLS */
  gk_dset(A->ncols, 0, w); 
  bcsol(ctrl, A, b, w, Wrk, bl, bu, beta, c); 
    
  /* recover full A, specific to binary A, this will over-write the column of b, 
     but will not matter */
  memcpy((void *)A->colval, (void *)*A_colval, sizeof(float)*nnz); 
  /* activate all columns */
  gk_iset(A->ncols, 1, acol);

}
      




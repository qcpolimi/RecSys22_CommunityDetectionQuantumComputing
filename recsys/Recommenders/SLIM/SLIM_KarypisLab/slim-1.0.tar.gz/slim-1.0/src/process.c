/**********************************************************/
/*! \file
  \brief This file constains routines for data pre-processing
 */
/**********************************************************/


#include<slim.h>


/**********************************************************/
/*! \brief Pre-process the data
 */
/**********************************************************/
void preprocess(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test){

  gk_csr_CreateIndex(train, GK_CSR_COL); 

  /* sort column indices */
  gk_csr_SortIndices(train, GK_CSR_ROW); 
  if (test){
    gk_csr_SortIndices(test,  GK_CSR_ROW); 

    /* sanity check */
    if (ctrl->dbglvl > 1)
      check_train_test(ctrl, train, test);
  }

  /* all in column-view of the training matrix */
  gk_csr_CreateIndex(train, GK_CSR_COL); 

}




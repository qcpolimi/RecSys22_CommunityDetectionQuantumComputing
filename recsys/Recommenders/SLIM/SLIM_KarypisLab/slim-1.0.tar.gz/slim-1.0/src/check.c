/**********************************************************/
/*! \file
    \brief This file constains routines for data pre-processing
*/
/**********************************************************/


#include<slim.h>


/**********************************************************/
/*! \brief Check if test data are already in train data
  
    \param[in] ctrl   A ctrl structure
    \param[in] train  The training data
    \param[in] test   The testing data
 */
/**********************************************************/
void check_train_test(ctrl_t * ctrl, gk_csr_t * train, gk_csr_t * test){

  int error = 0; 

  int nrows_test = test->nrows; 

  for (int i = 0; i < nrows_test; i ++){
    
    int nc_test = test->rowptr[i+1] - test->rowptr[i]; 
    int nc_train = train->rowptr[i+1] - train->rowptr[i]; 

    for (int j = 0; j < nc_test; j ++){
      
      int item_test = *(test->rowptr[i] + j + test->rowind); 
      
      for (int k = 0; k < nc_train; k ++){
	
	int item_train = *(train->rowptr[i] + k + train->rowind); 

	if (item_test == item_train){
	  printf("ERROR: user %6d has item %6d in both train and test\n", i, item_train); 
	  error = 1; 
	  break; 
	}

      }

    }

  }

  if (error)
    errexit("ERROR: train and test not disjoint\n"); 

}
